package com.system.ControleSaida.repository;

import com.system.ControleSaida.model.Saida;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaidaRepository extends JpaRepository<Saida, Long> {
}
